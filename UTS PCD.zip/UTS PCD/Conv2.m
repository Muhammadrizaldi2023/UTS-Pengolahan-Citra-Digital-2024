clear;clc;
gambar=imread('D:\OCTAVE\Tugas\Gorila.jpg');
mask=[-1 -1 -1; -1 7 -1;-1 -1 -1];
gray=rgb2gray(gambar);
thresh=graythresh(gray);
imbw=im2bw(gray,thresh);
result=conv2(double(imbw),mask,'valid');
figure, subplot(1,2,1), imshow(gambar), title('Gambar Asli'),
subplot(1,2,2),imshow(result),title('Hasil Konvolusi');
