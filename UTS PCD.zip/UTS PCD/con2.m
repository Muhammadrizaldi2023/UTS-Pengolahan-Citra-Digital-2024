% Bersihkan layar dan variabel
clear;
clc;

% Load paket gambar
pkg load image;

% Daftar nama file gambar
fileNames = {'Gorila.jpg', 'Burung.png', 'salju.jpg', 'jam.jpg', 'kupu.png', 'gunung.png'};

% Buat figure
figure;

% Proses setiap gambar
for i = 1:length(fileNames)
    % Baca gambar
    gambar = imread(['D:\OCTAVE\Tugas\' fileNames{i}]);

    % Pastikan gambar berhasil dibaca
    if isempty(gambar)
        error(['Gagal membaca gambar ' fileNames{i} '. Pastikan path file gambar benar.']);
    end

    % Konversi ke grayscale
    gray = rgb2gray(gambar);

    % Ambil threshold menggunakan Otsu's method
    thresh = graythresh(gray);

    % Binarisasi gambar
    imbw = im2bw(gray, thresh);

    % Tentukan mask
    mask = [-1 -1 -1; -1 7 -1; -1 -1 -1];

    % Lakukan konvolusi
    result = conv2(double(imbw), mask, 'valid');

    % Plot gambar asli dan hasil konvolusi
    subplot(6, 2, 2*i-1);
    imshow(gambar);
    title(['Gambar Asli ' num2str(i)]);

    subplot(6, 2, 2*i);
    imshow(result);
    title(['Hasil Konvolusi ' num2str(i)]);
end


